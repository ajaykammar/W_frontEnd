import React from 'react'
import CartItem from '../components/Cart/CartItem'

const Cart = () => {
  return (
    <div>
      <CartItem/>
    </div>
  )
}

export default Cart
