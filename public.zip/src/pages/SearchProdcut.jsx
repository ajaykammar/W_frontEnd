import React from "react";
import ProductsSearch from "../components/Prodcut/ProductsSearch";

const SearchProdcut = () => {
  return (
    <div>
      <ProductsSearch />
    </div>
  );
};

export default SearchProdcut;
